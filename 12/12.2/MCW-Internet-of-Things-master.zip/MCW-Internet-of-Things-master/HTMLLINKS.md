﻿# HTML Files for Workshop
[WDS student guide - Internet of Things.html](https://cloudworkshop.blob.core.windows.net/internet-of-things/Whiteboard%20design%20session/WDS%20student%20guide%20-%20Internet%20of%20Things.html)

[WDS trainer guide - Internet of Things.html](https://cloudworkshop.blob.core.windows.net/internet-of-things/Whiteboard%20design%20session/WDS%20trainer%20guide%20-%20Internet%20of%20Things.html)

[Before the HOL - Internet of Things.html](https://cloudworkshop.blob.core.windows.net/internet-of-things/Hands-on%20lab/Before%20the%20HOL%20-%20Internet%20of%20Things.html)

[HOL step-by-step - Internet of Things.html](https://cloudworkshop.blob.core.windows.net/internet-of-things/Hands-on%20lab/HOL%20step-by-step%20-%20Internet%20of%20Things.html)

